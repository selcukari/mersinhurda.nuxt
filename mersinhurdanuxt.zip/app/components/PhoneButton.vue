<template>
  <a
    href="tel:+905335907468"
    class="phone-button"
    aria-label="Telefon ile Arayın"
  >
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="70" 
      height="70" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      stroke-width="2.5" 
      stroke-linecap="round" 
      stroke-linejoin="round"
    >
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
    </svg>
  </a>
</template>

<style scoped>
.phone-button {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 9999;
  
  /* Mantine size ve radius değerlerinin karşılığı */
  width: 150px;
  height: 130px;
  border-radius: 9999px; /* Tam yuvarlak (radius="xl") */
  
  /* Renkler (color="green" ve variant="filled") */
  background-color: #22c55e;
  color: #ffffff;
  
  /* Hizalama */
  display: flex;
  align-items: center;
  justify-content: center;
  
  /* Gölge ve Geçişler */
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  transition: transform 0.2s ease, background-color 0.2s ease;
  text-decoration: none;
}

.phone-button:hover {
  background-color: #16a34a;
  transform: scale(1.05); /* Tıklandığında veya üzerine gelindiğinde güzel bir efekt */
}
</style>